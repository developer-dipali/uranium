const jwt=require("jsonwebtoken");

const auth= function ( req, res, next) {
    console.log("Hi I am a middleware named Mid4")
    let token = req.headers["x-Auth-token"];
  if (!token) token = req.headers["x-auth-token"];

 
  if (!token) return res.send({ status: false, msg: "token must be present" });

  console.log(token);
  
  let decodedToken = jwt.verify(token, "functionup-thorium");
  if (!decodedToken)
    return res.send({ status: false, msg: "token is invalid" });
    
    next()
}

module.exports.auth=auth