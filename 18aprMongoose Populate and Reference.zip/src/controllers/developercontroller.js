
const batchModel = require("../models/batchModel")
const developerModel = require("../models/developerModel")

// =====>
const developersdata = async function (req, res) {
    let developer = req.body
    let createdeveloper = await developerModel.create(developer)
    res.send({ data: createdeveloper })
}
// =====>
const scholarshipDeveloper = async function (req, res) {
    let developers = await developerModel.find({ gender: "female", percentage: { $gte: 70 } }).select({ name: 1, _id: 0 })
    res.send({ msg: developers })
}

// =====================================================//
const developers = async function (req, res) {
    let data=req.quary
    const per = data.percentage
    const batchname = data.program
    //let reqBatch=await batchModel.find({name:batchname}).select({name:1,_id:0})
    let dev = await developerModel.find({ percentage: { $gre:per }, program:batchname }).populate(batchId)
    res.send({ msg: dev })
}
    //     let findDeveloper=await developerModel.find({}) 





    //=======================================================//




    module.exports.developersdata = developersdata
    module.exports.scholarshipDeveloper = scholarshipDeveloper
    module.exports.developers = developers
